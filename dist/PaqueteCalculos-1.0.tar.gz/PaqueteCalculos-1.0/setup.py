from setuptools import setup

setup(#descripcion del paquetes
    name="PaqueteCalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Fabricio",
    author_email="fabricio@fabricio.com",
    url="www.yputube.com",
    packages=["calculos","calculos.redondeo_potencia"]
    )
